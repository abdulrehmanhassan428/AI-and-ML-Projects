

from linkedlist import DoublyLinkedList
import heapq

class State:
    #Task1
    #Actions and Successor Functions
    
    def __lt__(self, other):
        return str(self.tiles) < str(other.tiles)
    
    def __init__(self, tiles):
        self.tiles = tiles
        self.prev = None

    def __repr__(self):
        s = ""
        for row in self.tiles:
            for x in row:
                s += f"{x} "
            s += "\n"
        return s

    def __eq__(self, other):
        return str(self) == str(other)

    def __hash__(self):
        return hash(tuple([tuple(r) for r in self.tiles]))

    def copy(self):
        new_tiles = [row[:] for row in self.tiles]
        return State(new_tiles)

    def is_goal(self):
        counter = 1
        N = len(self.tiles)
        for i in range(N):
            for j in range(N):
                if i == N-1 and j == N-1:
                    return self.tiles[i][j] == " "
                if self.tiles[i][j] != counter:
                    return False
                counter += 1
        return True

    def get_neighbs(self):
        N = len(self.tiles)
        neighbs = []

        r = c = 0
        for i in range(N):
            for j in range(N):
                if self.tiles[i][j] == " ":
                    r, c = i, j

        for nr, nc in [[r-1,c], [r+1,c], [r,c-1], [r,c+1]]:
            if 0 <= nr < N and 0 <= nc < N:
                new_state = self.copy()
                new_state.tiles[r][c], new_state.tiles[nr][nc] = new_state.tiles[nr][nc], new_state.tiles[r][c]
                neighbs.append(new_state)

        return neighbs
#######################################################################################################################################

#Task 2:


def BFS(initial):
    frontier = DoublyLinkedList()
    frontier.add_last(initial)

    visited = set([initial])
    expanded = 0

    while len(frontier) > 0:
        state = frontier.remove_first()
        expanded += 1

        if state.is_goal():
            path = []
            while state:
                path.append(state)
                state = state.prev
            return path[::-1], expanded

        for n in state.get_neighbs():
            if n not in visited:
                visited.add(n)
                n.prev = state
                frontier.add_last(n)

    return None, expanded



##############################################################################################################################
#Task 3:


def DFS(initial):
    stack = DoublyLinkedList()
    stack.add_last(initial)

    visited = set()
    expanded = 0

    while len(stack) > 0:
        state = stack.remove_last()
        expanded += 1

        if state.is_goal():
            path = []
            while state:
                path.append(state)
                state = state.prev
            return path[::-1], expanded

        visited.add(state)

        for n in state.get_neighbs():
            if n not in visited:
                n.prev = state
                stack.add_last(n)

    return None, expanded


############################################################################################################################
#Task 4:

def misplaced_heuristic(state):
    goal = list(range(1,9)) + [" "]
    flat = [x for row in state.tiles for x in row]

    h = 0
    for i in range(9):
        if flat[i] != goal[i]:
            if flat[i] != " ":
                h += 1
    return h


def A_star(initial):
    open_list = []
    g = {initial: 0}
    h = misplaced_heuristic(initial)

    heapq.heappush(open_list, (h, initial))

    visited = set()
    expanded = 0

    while open_list:
        _, state = heapq.heappop(open_list)
        expanded += 1

        if state.is_goal():
            path = []
            while state:
                path.append(state)
                state = state.prev
            return path[::-1], expanded

        visited.add(state)

        for n in state.get_neighbs():
            if n in visited:
                continue

            cost = g[state] + 1  

            if n not in g or cost < g[n]:
               g[n] = cost
               n.prev = state
               f = cost + misplaced_heuristic(n)
               heapq.heappush(open_list, (f, n))

    return None, expanded


#############################################################################################################################
#Task 5:


def compare_algorithms(initial):

    bfs_path, bfs_nodes = BFS(initial)
    print("\n")
    print(f"BFS total nodes: {bfs_nodes}")

    dfs_path, dfs_nodes = DFS(initial)
    print("\n")
    print(f"DFS Total nodes: {dfs_nodes}")


    astar_path, astar_nodes = A_star(initial)
    print("\n")
    print(f"A*  nodes: {astar_nodes}")

    best = min([
        ("BFS", bfs_nodes),
        ("DFS", dfs_nodes),
        ("A*", astar_nodes)
    ], key=lambda x: x[1])

    print(f"\n {best[0]} (These are the minimum nodes)")


print("Enter 9 values in a row, 0 for blank:")
vals = input().split()

tiles = []
k = 0
for i in range(3):
    row = []
    for j in range(3):
        x = vals[k]
        if x == "0":
            x = " "
        row.append(int(x) if x.isdigit() else " ")
        k += 1
    tiles.append(row)

initial = State(tiles)

compare_algorithms(initial)

